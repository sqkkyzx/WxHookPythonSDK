from distutils.core import setup

setup(
    name='deanwxhook',
    version='1.1',
    packages=[''],
    url='https://cos-1255906436.cos.ap-shanghai.myqcloud.com/application/deanwxhook-1.0.tar.gz',
    license='',
    author='YIZIXUAN',
    author_email='',
    description=''
)
